# API de Pedidos - Spring Boot

## Descrição
Projeto simples de API REST em Spring Boot para gerenciar pedidos (Orders).  
Possui endpoints para listar e criar pedidos.

## Como rodar

1. Clone o repositório:
```bash
git clone https://github.com/f-alexandre96/ApiSpringBootADS.git
